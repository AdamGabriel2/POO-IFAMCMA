def divide(x, y):
    assert y != 0, "Divisão por zero não é permitida"
    return x / y
print(divide(50, 5))
print(divide(10, 0))
print(divide(10, 2))