def soma(a, b):
    assert isinstance(a, int) and isinstance(b, int), "A e B devem ser inteiros"
    return a + b
print(soma(2, 3))
print(soma('a', 3))
print(soma('a', 'b'))
print(soma(50, 10))
print("akjsdlkjsadlkja")