def encontrar_maior(lista):
    if len(lista) == 0:
        return -1
    return max(lista)
print(encontrar_maior([1, 2, 3, 4]))
print(encontrar_maior([21, 421, 4, 432, 253, 523]))
print("... continua o codigo")