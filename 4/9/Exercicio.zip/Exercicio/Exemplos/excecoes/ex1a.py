while True:
    x = int(input("Digite um número: "))
    y = int(input("Digite outro número: "))
    resultado = x / y
print(f"O resultado é: {resultado}")
print("... continua o programa")