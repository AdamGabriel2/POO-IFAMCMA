try:
    resultado = 'abc' + 123
except TypeError:
    print("Erro: Não é possível somar uma string e um número!")
print("... continua o programa")