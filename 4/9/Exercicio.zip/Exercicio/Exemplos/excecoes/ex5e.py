try:
    import biblioteca_inexistente
except ModuleNotFoundError:
    print("Erro: Biblioteca não encontrada!")
print("... continua o programa")