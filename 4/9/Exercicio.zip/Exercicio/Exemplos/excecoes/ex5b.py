try:
    numero = int(input("Digite um número: "))
except ValueError:
    print("Erro: Você não digitou um número válido!")
print("... continua o programa")